<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>SIWS College : Home</title>
  <link rel="stylesheet" href="style.css" />
</head>
<body>

  <!-- Header -->
  <div class="header">
    <img src="siws_logo.png" class="logo" alt="SIWS Logo" />
    <div class="college-name">
      <h1>
        <span class="siws">SIWS</span>
        <span class="full">N.R. SWAMY COLLEGE OF COMMERCE & ECONOMICS AND SMT. THIRUMALAI COLLEGE OF SCIENCE</span>
        <span class="autonomous">(AUTONOMOUS)</span>
      </h1>
      <p class="details">NAAC Re-Accredited A Grade | College Code 311 | AISHE CODE.C-34030 | Wadala, Mumbai</p>
    </div>
  </div>

  <!-- Announcement -->
  <div class="announcement">
    <marquee behavior="scroll" direction="left">📢 Admissions Open Now</marquee>
  </div>

  <!-- ✅ Navbar -->
  <?php include 'navbar.php'; ?> <!-- ← Ab yeh line navbar.php ko call karegi -->

  <!-- Hero Section -->
  <section class="hero">
    <h2>Empowering Your Future At</h2>
    <h1>SIWS College <span>(Autonomous)</span></h1>
    <a href="#" class="btn">Learn More</a>
  </section>

  <!-- Programs Section -->
  <section class="programs">
    <h2>Our Programs, your Future</h2>
    <p>Choose from specialized courses designed to set the foundation for a successful career.</p>
  </section>

</body>
</html>
