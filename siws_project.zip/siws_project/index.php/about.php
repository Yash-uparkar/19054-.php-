<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>About Us - SIWS College</title>
  <link rel="stylesheet" href="style.css" />
  <style>
    .about-container {
      max-width: 1200px;
      margin: auto;
      padding: 20px;
      display: flex;
      flex-wrap: wrap;
      align-items: center;
      gap: 20px;
    }

    .about-image {
      flex: 1;
      min-width: 300px;
    }

    .about-image img {
      width: 100%;
      border-radius: 10px;
    }

    .about-text {
      flex: 2;
      min-width: 300px;
    }

    .about-text h2 {
      color: #3c1e94;
      margin-bottom: 15px;
    }

    .about-text p {
      line-height: 1.6;
      color: #333;
    }

    .section {
      max-width: 1000px;
      margin: 40px auto;
      padding: 0 20px;
    }

    .section h2 {
      color: #3c1e94;
      text-align: center;
      margin-bottom: 20px;
    }

    .values-boxes,
    .core-goals-boxes {
      display: flex;
      flex-wrap: wrap;
      justify-content: center;
      gap: 20px;
    }

    .value,
    .goal {
      background-color: #f1f1f1;
      padding: 15px 20px;
      border-radius: 8px;
      width: 100%;
      max-width: 600px;
      cursor: pointer;
    }

    .vision-mission {
      display: flex;
      justify-content: center;
      flex-wrap: wrap;
      gap: 20px;
      margin-top: 30px;
    }

    .vision, .mission {
      background-color: #e6f0ff;
      padding: 15px;
      border-radius: 8px;
      max-width: 400px;
      flex: 1;
    }

    @media (max-width: 768px) {
      .about-container {
        flex-direction: column;
        text-align: center;
      }
    }
  </style>
</head>
<body>

<?php include 'navbar.php'; ?>

<section class="about-container">
  <div class="about-image">
    <img src="siws_project.png" alt="SIWS College" />
  </div>
  <div class="about-text">
    <h2>About SIWS College</h2>
    <p>
      Established in 1960, SIWS College has been a beacon of academic excellence in Commerce, Science, and Arts. Our mission is to nurture intellectual curiosity, promote leadership, and provide holistic development to every student.
    </p>
    <p>
      Accredited with an 'A' Grade by NAAC, we continue to innovate in education, research, and co-curricular growth. Located in Wadala, Mumbai, SIWS College is affiliated with Mumbai University and offers autonomous degree programs.
    </p>
  </div>
</section>

<section class="section">
  <h2>Overview</h2>
  <p style="text-align:center; font-style: italic; font-weight: bold;">
    “Vidya Dhanam Sarva Dhanat Pradhanam”
  </p>
  <p style="text-align:center;">
    emphasizes individual intellectual development, collaborative learning, and a strong commitment to serving the broader community
  </p>
  <br />
  <p>
    S.I.W.S. Degree College in Commerce and Economics was established in 1980 and Smt. Thirumalai College of Science in 1990. The Vision of SIWS College is to continually strive to respond to realities and social changes through knowledge empowerment. This is achieved through the Motto of SIWS “Vidya Dhanam Sarva Dhanat Pradhanam”. In pursuance of its Vision, SIWS is dedicated to produce socially responsible and intellectually capable citizens of India.
  </p>

  <div class="vision-mission">
    <div class="vision">
      <strong>Our Vision</strong><br />
      To be an educational institution of brilliance that continually strives to respond to realities and social changes through knowledge empowerment.
    </div>
    <div class="mission">
      <strong>Our Mission</strong><br />
      In pursuance of its vision, SIWS is dedicated to produce socially responsible and intellectually capable citizens of India.
    </div>
  </div>
</section>

<section class="section">
  <h2>Our Values</h2>
  <div class="values-boxes">
    <div class="value">Excellence in Education</div>
    <div class="value">Inclusivity and Equity</div>
    <div class="value">Sustainability and Environmental Responsibility</div>
    <div class="value">Community Engagement</div>
    <div class="value">Technological Advancement</div>
    <div class="value">Ethical Leadership</div>
    <div class="value">Global Citizenship</div>
    <div class="value">Health and Wellbeing</div>
    <div class="value">Creativity and Innovation</div>
    <div class="value">Resilience and Adaptability</div>
  </div>
</section>

<section class="section">
  <h2>Core Goals</h2>
  <p style="text-align: center;">
    At SIWS College, our core goals are achieving academic excellence, inculcating moral values, promoting multicultural harmony and inducing social responsibility.
  </p>
  <br />
  <div class="core-goals-boxes">
    <div class="goal">Excellence in Education</div>
    <div class="goal">Inclusivity and Equity</div>
    <div class="goal">Sustainability and Environmental Responsibility</div>
    <div class="goal">Community Engagement</div>
    <div class="goal">Technological Advancement</div>
    <div class="goal">Ethical Leadership</div>
    <div class="goal">Global Citizenship</div>
    <div class="goal">Health and Wellbeing</div>
    <div class="goal">Creativity and Innovation</div>
    <div class="goal">Resilience and Adaptability</div>
  </div>
</section>

</body>
</html>
