document.querySelector('.menu-toggle').addEventListener('click', function () {
  document.querySelector('.navbar ul').classList.toggle('show');
});