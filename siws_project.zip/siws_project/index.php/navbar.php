<!-- navbar.php -->
<nav class="navbar">
  <div class="menu-toggle">&#9776;</div>
  <ul>
    <li><a href="about.php">About Us</a></li>
    <li><a href="academics.php">Academics</a></li>
    <li><a href="admissions.php">Admissions</a></li>
    <li><a href="amenities.php">Amenities</a></li>
    <li><a href="student_corner.php">Student Corner</a></li>
    <li><a href="contact.php">Contact Us</a></li>
    <li><a href="quicklinks.php">Quicklinks</a></li>
  </ul>
</nav>

<script>
  document.querySelector('.menu-toggle').addEventListener('click', function () {
    document.querySelector('.navbar ul').classList.toggle('show');
  });
</script>
